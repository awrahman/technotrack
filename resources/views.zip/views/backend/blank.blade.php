@extends('backend.layout.app')
@section('title','Blank')
@push('css')
@endpush
@section('main_menu','HOME')
@section('active_menu','Blank')
@section('link',route('admin.adminDashboard'))
@section('content')











@endsection
@push('js')
@endpush
